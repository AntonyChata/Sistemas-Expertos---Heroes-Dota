# informe_latex
Modelo de informe en Latex tipo artículo, adecuado para la Escuela de Sistemas.

Editar el archivo "informe.tex"
